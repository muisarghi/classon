<?php
@ini_set('display_errors', 'on');
include ('layout/header.php');
include ('layout/class.php');
//include ('layout/function.php');
include ('layout/footer.php');
?>