<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bootstrap Testimonial Carousel with Quote Icon</title>

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
body {
	font-family: "Open Sans", sans-serif;
}
h2 {
	color: #000;
	font-size: 26px;
	font-weight: 300;
	text-align: center;
	text-transform: uppercase;
	position: relative;
	margin: 30px 0 70px;
}
h2::after {
	content: "";
	width: 100px;
	position: absolute;
	margin: 0 auto;
	height: 4px;
	border-radius: 1px;
	background: #1c47e3;
	left: 0;
	right: 0;
	bottom: -20px;
}
.carousel {
	margin: 50px auto;
	padding: 0 70px;
}
.carousel .item {
	color: #999;
	overflow: hidden;
    min-height: 120px;
	font-size: 13px;
}
.carousel .media img {
	width: 80px;
	height: 80px;
	display: block;
	border-radius: 50%;
}
.carousel .testimonial {
	padding: 0 15px 0 60px ;
	position: relative;
}
.carousel .testimonial::before {
	content: '\93';
	color: #e2e2e2;
	font-weight: bold;
	font-size: 68px;
	line-height: 54px;
	position: absolute;
	left: 15px;
	top: 0;
}
.carousel .overview b {
	text-transform: uppercase;
	color: #1c47e3;
}
.carousel .carousel-indicators {
	bottom: -40px;
}
.carousel-indicators li, .carousel-indicators li.active {
	width: 18px;
    height: 18px;
	border-radius: 50%;
	margin: 1px 3px;
}
.carousel-indicators li {	
    background: #e2e2e2;
    border: 4px solid #fff;
}
.carousel-indicators li.active {
	color: #fff;
    background: #1c47e3;    
    border: 5px double;    
}
</style>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h2>What <b>our customers</b> are saying</h2>
			<div id="myCarousel" class="carousel slide" data-ride="carousel">
				<!-- Carousel indicators -->
				<ol class="carousel-indicators">
					<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1"></li>
					<li data-target="#myCarousel" data-slide-to="2"></li>
				</ol>   
				<!-- Wrapper for carousel items -->
				<div class="carousel-inner">
					<div class="item carousel-item active">
						<div class="row">
							<div class="col-sm-6">
								<div class="">
									<img src="img/agent-1.jpg" width='100%' height='auto'>
								</div>
							</div>
							
							<div class="col-sm-6">
								<div class="media">
									<div class="media-left d-flex mr-3">
										<a href="#">
											
										</a>
									</div>
									<div class="media-body">
										<div class="testimonial">
											<p>Vestibulum quis quam ut magna consequat faucibus. Pellentesque eget mi suscipit tincidunt. Utmtc tempus dictum. Pellentesque virra.</p>
											<br>
											

											<p class="overview"><img src="img/agent-1.jpg" alt="" style="float: left; vertical-align:middle;"> <br><br>
											&nbsp;&nbsp;
											<b>Antonio Moreno</b>, Web Developer</p>
										</div>
									</div>
								</div>
							</div>
						</div>			
					</div>

					<div class="item carousel-item ">
						<div class="row">
							<div class="col-sm-6">
								<div class="">
									<img src="img/agent-2.jpg" width='100%' height='auto'>
								</div>
							</div>
							
							<div class="col-sm-6">
								<div class="media">
									<div class="media-left d-flex mr-3">
										<a href="#">
											
										</a>
									</div>
									<div class="media-body">
										<div class="testimonial">
											<p>Vestibulum quis quam ut magna consequat faucibus. Pellentesque eget mi suscipit tincidunt. Utmtc tempus dictum. Pellentesque virra.</p>
											<br>
											

											<p class="overview"><img src="img/agent-2.jpg" alt="" style="float: left; vertical-align:middle;"> <br><br>
											&nbsp;&nbsp;
											<b>Barack Obama</b>, President</p>
										</div>
									</div>
								</div>
							</div>
						</div>			
					</div>
					
					<!--
					<div class="item carousel-item">
						<div class="row">
							<div class="col-sm-6">
								<div class="media">
									<div class="media-left d-flex mr-3">
										<a href="#">
											<img src="/examples/images/clients/3.jpg" alt="">
										</a>
									</div>
									<div class="media-body">
										<div class="testimonial">
											<p>Lorem ipsum dolor sit amet, consec adipiscing elit. Nam eusem scelerisque tempor, varius quam luctus dui. Mauris magna metus nec.</p>
											<p class="overview"><b>Michael Holz</b>, Seo Analyst</p>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-sm-6">
								<div class="media">
									<div class="media-left d-flex mr-3">
										<a href="#">
											<img src="/examples/images/clients/4.jpg" alt="">
										</a>
									</div>
									<div class="media-body">
										<div class="testimonial">
											<p>Vestibulum quis quam ut magna consequat faucibus. Pellentesque eget mi suscipit tincidunt. Utmtc tempus dictum. Pellentesque virra.</p>
											<p class="overview"><b>Mary Saveley</b>, Web Designer</p>
										</div>
									</div>
								</div>
							</div>
						</div>			
					</div>
					
					<div class="item carousel-item">
						<div class="row">
							<div class="col-sm-6">
								<div class="media">
									<div class="media-left d-flex mr-3">
										<a href="#">
											<img src="/examples/images/clients/5.jpg" alt="">
										</a>
									</div>
									<div class="media-body">
										<div class="testimonial">
											<p>Lorem ipsum dolor sit amet, consec adipiscing elit. Nam eusem scelerisque tempor, varius quam luctus dui. Mauris magna metus nec.</p>
											<p class="overview"><b>Martin Sommer</b>, UX Analyst</p>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="media">
									<div class="media-left d-flex mr-3">
										<a href="#">
											<img src="/examples/images/clients/6.jpg" alt="">
										</a>
									</div>
									<div class="media-body">
										<div class="testimonial">
											<p>Vestibulum quis quam ut magna consequat faucibus. Pellentesque eget mi suscipit tincidunt. Utmtc tempus dictum. Pellentesque virra.</p>
											<p class="overview"><b>John Williams</b>, Web Developer</p>
										</div>
									</div>
								</div>
							</div>
						</div>			
					</div>
				-->
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>                  