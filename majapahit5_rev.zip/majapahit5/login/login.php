<?php
include '../layout/header.php';
?>
<section class="engine"><a href="https://mobirise.info/q">free responsive site templates</a></section><section class="mbr-section content5 cid-rs5SVL0d7A mbr-parallax-background" id="content5-17">

    

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1">
                    Login Administrator</h2>
            </div>
        </div>
    </div>
</section>


<section class="mbr-section article content9 cid-rs5T14fBsX" id="content9-18">
    <div class="container">
        <div class="inner-container" style="width: 100%;">
			<table width='80%'> 
			<tr>
			<td width='25%'>Username</td>
			<td><input type='text' name='user' class='form-control'></td>
			</tr>

			<tr>
			<td>Password</td>
			<td><input type='password' name='pass' class='form-control'></td>
			</tr>

			<tr>
			<td></td>
			<td><input type='submit' value='LOGIN' class='btn btn-primary'></td>
			</tr>
			</table>
		</div>
	</div>
</section>

<?php
include '../layout/footer.php';
?>