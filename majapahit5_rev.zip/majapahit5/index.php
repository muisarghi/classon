<?php
@ini_set('display_errors', 'off');
include 'layout/header.php';

//include 'layout/home.php';
//include 'inc/inc.php';
include 'layout/panel.php';

include 'layout/footer.php';
?>

