<section class="engine"><a href="https://mobirise.info/i">site creation software</a></section><section class="carousel slide cid-rs0XWDKLqr" data-interval="false" id="slider1-1">

    <div class="full-screen"><div class="mbr-slider slide carousel" data-pause="true" data-keyboard="false" data-ride="false" data-interval="false"><ol class="carousel-indicators"><li data-app-prevent-settings="" data-target="#slider1-1" data-slide-to="0"></li><li data-app-prevent-settings="" data-target="#slider1-1" data-slide-to="1"></li><li data-app-prevent-settings="" data-target="#slider1-1" class=" active" data-slide-to="2"></li></ol><div class="carousel-inner" role="listbox"><div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="assets/images/slide-1.jpg"><div class="carousel-caption justify-content-center"><div class="col-10 align-center"><h2 class="mbr-fonts-style display-1"><strong>SMAN 1 Majapahit</strong></h2><p class="lead mbr-text mbr-fonts-style display-5">Selamat datang di SMA 1 Majapahit , Sekolan Unggul insan berbudi pekerti dengan mengedepankan aspek teknologi</p></div></div></div></div></div><div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="assets/images/slide-2.jpg"><div class="carousel-caption justify-content-center"><div class="col-10 align-center"><h2 class="mbr-fonts-style display-1"><strong>SMAN 1 Majapahit</strong></h2><p class="lead mbr-text mbr-fonts-style display-5">Selamat datang di SMA 1 Majapahit , Sekolan Unggul insan berbudi pekerti dengan mengedepankan aspek teknologi</p></div></div></div></div></div><div class="carousel-item slider-fullscreen-image active" data-bg-video-slide="false"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="assets/images/slide-3.jpg"><div class="carousel-caption justify-content-center"><div class="col-10 align-center"><h2 class="mbr-fonts-style display-1"><strong>SMAN 1 Majapahit</strong></h2><p class="lead mbr-text mbr-fonts-style display-5">Selamat datang di SMA 1 Majapahit , Sekolan Unggul insan berbudi pekerti dengan mengedepankan aspek teknologi</p></div></div></div></div></div></div><a data-app-prevent-settings="" class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#slider1-1"><span aria-hidden="true" class="mbri-left mbr-iconfont"></span><span class="sr-only">Previous</span></a><a data-app-prevent-settings="" class="carousel-control carousel-control-next" role="button" data-slide="next" href="#slider1-1"><span aria-hidden="true" class="mbri-right mbr-iconfont"></span><span class="sr-only">Next</span></a></div></div>

</section>

<section class="features1 cid-rs13klJ2dg" id="features1-2">
    
    

    
    <div class="container">
        <div class="media-container-row">

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-img pb-3">
                    <span class="mbr-iconfont mbri-bookmark"></span>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Sekolah Negeri</h4>
                    
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-img pb-3">
                    <span class="mbr-iconfont mbri-idea"></span>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Akreditasi - A</h4>
                    
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-img pb-3">
                    <span class="mbr-iconfont mbri-star"></span>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Prestasi</h4>
                    
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-img pb-3">
                    <span class="mbr-iconfont mbri-user2"></span>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Pengajar</h4>
                    
                </div>
            </div>

        </div>

    </div>

</section>

<section class="header7 cid-rs15acSsAP" id="header7-3">

    

    

    <div class="container">
        <div class="media-container-row">

            <div class="media-content align-right">
                <h1 class="mbr-section-title mbr-white pb-3 mbr-fonts-style display-1">
                    Profile Sekolah</h1>
                <div class="mbr-section-text mbr-white pb-3">
                    <p class="mbr-text mbr-fonts-style display-5">
                        Menerima Siswa Baru Tahun Pelajaran 2019/2020. Mendidik Moral, Karakter didamping Iptek dan ImtaqBiaya Terjangkau, Mendapat Perlengkapan Sekolah</p>
                </div>
                
            </div>

            <div class="mbr-figure" style="width: 100%;"><iframe class="mbr-embedded-video" src="https://www.youtube.com/embed/U0B1kNnxTs4?rel=0&amp;amp;showinfo=0&amp;autoplay=0&amp;loop=0" width="1280" height="720" frameborder="0" allowfullscreen></iframe></div>

        </div>
    </div>
</section>

<section class="mbr-gallery mbr-slider-carousel cid-rs16LmQYTh" id="gallery2-4">

    

    <div>
        <div><!-- Filter --><div class="mbr-gallery-filter container gallery-filter-active"><ul buttons="0"><li class="mbr-gallery-filter-all"><a class="btn btn-md btn-primary-outline active display-7" href="">All</a></li></ul></div><!-- Gallery --><div class="mbr-gallery-row"><div class="mbr-gallery-layout-default"><div><div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Sekolah"><div href="#lb-gallery2-4" data-slide-to="0" data-toggle="modal"><img src="assets/images/upacara-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Ekstrakurikuler"><div href="#lb-gallery2-4" data-slide-to="1" data-toggle="modal"><img src="assets/images/basket-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Sekolah"><div href="#lb-gallery2-4" data-slide-to="2" data-toggle="modal"><img src="assets/images/bimbel-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Sekolah"><div href="#lb-gallery2-4" data-slide-to="3" data-toggle="modal"><img src="assets/images/osis-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Ekstrakurikuler"><div href="#lb-gallery2-4" data-slide-to="4" data-toggle="modal"><img src="assets/images/pramuka-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Sekolah"><div href="#lb-gallery2-4" data-slide-to="5" data-toggle="modal"><img src="assets/images/ruang-kelas-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Studi Banding"><div href="#lb-gallery2-4" data-slide-to="6" data-toggle="modal"><img src="assets/images/study-banding-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div><div class="mbr-gallery-item mbr-gallery-item--p2" data-video-url="false" data-tags="Kelas"><div href="#lb-gallery2-4" data-slide-to="7" data-toggle="modal"><img src="assets/images/tik-600x400-600x400.jpg" alt="" title=""><span class="icon-focus"></span></div></div></div></div><div class="clearfix"></div></div></div><!-- Lightbox --><div data-app-prevent-settings="" class="mbr-slider modal fade carousel slide" tabindex="-1" data-keyboard="true" data-interval="false" id="lb-gallery2-4"><div class="modal-dialog"><div class="modal-content"><div class="modal-body"><div class="carousel-inner"><div class="carousel-item"><img src="assets/images/upacara-600x400.jpg" alt="" title=""></div><div class="carousel-item"><img src="assets/images/basket-600x400.jpg" alt="" title=""></div><div class="carousel-item"><img src="assets/images/bimbel-600x400.jpg" alt="" title=""></div><div class="carousel-item"><img src="assets/images/osis-600x400.jpg" alt="" title=""></div><div class="carousel-item"><img src="assets/images/pramuka-600x400.jpg" alt="" title=""></div><div class="carousel-item"><img src="assets/images/ruang-kelas-600x400.jpg" alt="" title=""></div><div class="carousel-item"><img src="assets/images/study-banding-600x400.jpg" alt="" title=""></div><div class="carousel-item active"><img src="assets/images/tik-600x400.jpg" alt="" title=""></div></div><a class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#lb-gallery2-4"><span class="mbri-left mbr-iconfont" aria-hidden="true"></span><span class="sr-only">Previous</span></a><a class="carousel-control carousel-control-next" role="button" data-slide="next" href="#lb-gallery2-4"><span class="mbri-right mbr-iconfont" aria-hidden="true"></span><span class="sr-only">Next</span></a><a class="close" href="#" role="button" data-dismiss="modal"><span class="sr-only">Close</span></a></div></div></div></div></div>
    </div>

</section>

<section class="mbr-section info2 cid-rs17CnFvUg" id="info2-8">

    

    

    <div class="container">
        <div class="row main justify-content-center">
            <div class="media-container-column col-12 col-lg-3 col-md-4">
                <div class="mbr-section-btn align-left py-4"><a class="btn btn-primary display-4" href="index.html"><span class="mbrib-edit mbr-iconfont mbr-iconfont-btn"></span>
                    DAFTAR SEKARANG</a></div>
            </div>
            <div class="media-container-column title col-12 col-lg-7 col-md-6">
                <h2 class="align-right mbr-bold mbr-white pb-3 mbr-fonts-style display-2">Jadilah Bagian Dari Masa Depan Terbaik</h2>
                
            </div>
        </div>
    </div>
</section>

<section class="mbr-section content4 cid-rs16XziUI1" id="content4-5">

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center pb-3 mbr-fonts-style display-2">
                    Berita Sekolah</h2>
                
                
            </div>
        </div>
    </div>
</section>

<section class="features3 cid-rs172xXCrl" id="features3-7">

    

    
    <div class="container">
        <div class="media-container-row">
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/siswa-siswi-smk-26-jakarta-menunggu-kedatangan-anies-s-20180630-103040-676x380.jpg" alt="Mobirise" title="">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">Kegiatan Tengah Semester Makin Meriah</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Kegiatan Tengah semester di isi kegiatan yang positif tidak pernah konvoi di jalan apalagi tidak produktif.
                        </p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="page12.html" class="btn btn-primary display-4">
                            Selengkapnya</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/bv3jwxlw61-1-600x330.jpg" alt="Mobirise" title="">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">Siswa Siswi Rayakan Kelulusan Siang ini</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Siswa Siswi Rayakan Kelulusan Siang ini. tak konvoi di jalan justru mereka melakukan kegiatan positif dengan menyumbang baju untuk adik kelas.
                        </p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="page12.html" class="btn btn-primary display-4">
                            Selengkapnya</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/unsma-676x386.jpg" alt="Mobirise" title="">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">Kedatangan Pak Jokowi, Sabtu siang</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Sekolah ini tidak pernah menyangka bahwa sekolah mereka akan kedatangan orang nomer 1 di Indonesia.
                        </p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="page12.html" class="btn btn-primary display-4">
                            Selengkapnya</a></div>
                </div>
            </div>

            
        </div>
    </div>
</section>

<section class="testimonials5 cid-rs17IpJwff" id="testimonials5-9">

    

    <div class="mbr-overlay" style="opacity: 0.9; background-color: rgb(193, 193, 193);">
    </div>
    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 align-center">
                <h2 class="pb-3 mbr-fonts-style display-2">Kepala SMAN 1 Majapahit</h2>
                
            </div>
        </div>
    </div>

    <div class="container">
        <div class="media-container-column">
            

            
        <div class="mbr-testimonial align-center col-12 col-md-10">
                <div class="panel-item">
                    <div class="card-block">
                        <div class="testimonial-photo">
                            <img src="assets/images/tony-stark-240x259.jpg" alt="" title="">
                        </div>
                        <p class="mbr-text mbr-fonts-style mbr-white display-7">
                           You can work hard, but if you don't work smart , You'll work for the rest of your life</p>
                    </div>
                    <div class="card-footer">
                        <div class="mbr-author-name mbr-bold mbr-fonts-style mbr-white display-7">
                             Tony Stark</div>
                        <small class="mbr-author-desc mbr-italic mbr-light mbr-fonts-style mbr-white display-7">Kepala SMAN 1 Majapahit</small>
                    </div>
                </div>
            </div></div>
    </div>   
</section>