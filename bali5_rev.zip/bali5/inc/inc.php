<?php
//$conn=mysqli_connect("localhost","root","","sman1tam_webedu");
mysql_connect("localhost","root","");
mysql_select_db("webedu");
?>