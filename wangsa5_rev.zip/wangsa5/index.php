<?php
@ini_set('display_errors', 'off');
include ('layout/header.php');
include 'layout/class.php';

include ('layout/footer.php');
?>